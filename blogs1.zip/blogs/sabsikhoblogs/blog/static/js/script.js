
tinymce.init({
  selector: 'textarea'
});
